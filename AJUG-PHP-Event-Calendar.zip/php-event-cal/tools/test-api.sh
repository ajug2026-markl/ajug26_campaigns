#!/bin/bash
set -u

ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
CONFIG="${BC_CONFIG_FILE:-$ROOT/config/business-central.ini}"

if [ ! -f "$CONFIG" ]; then
    echo "Config not found: $CONFIG" >&2
    exit 1
fi

unset BC_BASE BC_COMPANY BC_TENANT BC_ENTITY BC_USER BC_PASS

eval "$(php -r '
$c=parse_ini_file($argv[1], true)["business_central"];
foreach ([
    "BC_BASE"=>"base_url",
    "BC_COMPANY"=>"company",
    "BC_TENANT"=>"tenant",
    "BC_ENTITY"=>"entity",
    "BC_USER"=>"username",
    "BC_PASS"=>"password"
] as $shell=>$key) {
    printf("%s=%s\\n", $shell, escapeshellarg((string)($c[$key] ?? "")));
}
' "$CONFIG")"

CANDIDATE_BASE="${1:-}"
CANDIDATE_TENANT="${2:-}"

TMPDIR="$(mktemp -d)"
trap 'rm -rf "$TMPDIR"' EXIT

RESULTS=()

check_url() {
    NAME="$1"
    URL="$2"
    ACCEPT="${3:-application/json}"
    FILE="$TMPDIR/body.txt"
    ERR="$TMPDIR/error.txt"

    META="$(
        curl -sS \
            --location \
            --connect-timeout 10 \
            --max-time 30 \
            -u "$BC_USER:$BC_PASS" \
            -H "Accept: $ACCEPT" \
            -o "$FILE" \
            -w '%{http_code}|%{url_effective}|%{content_type}' \
            "$URL" 2>"$ERR"
    )"

    CURL_RC=$?
    IFS='|' read -r HTTP_CODE EFFECTIVE_URL CONTENT_TYPE <<< "$META"

    echo
    echo "================================================================"
    echo "$NAME"
    echo "================================================================"
    echo "Requested URL : $URL"
    echo "Effective URL : ${EFFECTIVE_URL:-N/A}"
    echo "HTTP Status   : ${HTTP_CODE:-N/A}"
    echo "Content-Type  : ${CONTENT_TYPE:-N/A}"
    echo "curl exit     : $CURL_RC"

    if [ -s "$ERR" ]; then
        echo
        echo "curl error:"
        cat "$ERR"
    fi

    if [ -s "$FILE" ]; then
        echo
        echo "Response preview:"
        head -c 1200 "$FILE"
        echo
    else
        echo
        echo "Response body: <empty>"
    fi

    RESULTS+=("$NAME|${HTTP_CODE:-N/A}|$CURL_RC")
}

CURRENT_ROOT="$BC_BASE/?tenant=$BC_TENANT"
CURRENT_METADATA="$BC_BASE/\$metadata?tenant=$BC_TENANT"
CURRENT_COMPANY="$BC_BASE/Company?tenant=$BC_TENANT&\$select=Name&\$top=10"
CURRENT_ENTITY="$BC_BASE/Company('$BC_COMPANY')/$BC_ENTITY?tenant=$BC_TENANT&\$top=1"
CURRENT_FIELDS="$BC_BASE/Company('$BC_COMPANY')/$BC_ENTITY?tenant=$BC_TENANT&\$top=1&\$select=No,Description,Status_Code,Starting_Date,Ending_Date,AJE_Store_No,AJE_Campaign_Attr_01,AJE_Campaign_Attr_05,AJE_Campaign_Bool_Attr_01,AJE_Campaign_Bool_Attr_02,AJE_Campaign_Bool_Attr_03,AJE_Campaign_Bool_Attr_04,AJE_Campaign_Date_Attr_01,AJE_CRM_Enable_On_POS,Last_Date_Modified"

echo "################################################################"
echo "BUSINESS CENTRAL ODATA CONNECTIVITY TEST"
echo "################################################################"
echo "Test time      : $(date '+%Y-%m-%d %H:%M:%S %Z')"
echo "Server         : $(hostname -f 2>/dev/null || hostname)"
echo "Base           : $BC_BASE"
echo "Company        : $BC_COMPANY"
echo "Tenant         : $BC_TENANT"
echo "Entity         : $BC_ENTITY"
echo "API Username   : $BC_USER"
echo "API Password   : <loaded from config - not displayed>"

check_url "1. SERVICE ROOT" "$CURRENT_ROOT"
check_url "2. METADATA" "$CURRENT_METADATA" "application/xml"
check_url "3. COMPANY ENDPOINT" "$CURRENT_COMPANY"
check_url "4. EVENT ENTITY" "$CURRENT_ENTITY"
check_url "5. EVENT ENTITY - REQUIRED FIELDS" "$CURRENT_FIELDS"

if [ -n "$CANDIDATE_BASE" ] && [ -n "$CANDIDATE_TENANT" ]; then
    check_url "6. CANDIDATE SERVICE ROOT" \
        "$CANDIDATE_BASE/?tenant=$CANDIDATE_TENANT"
    check_url "7. CANDIDATE EVENT ENTITY" \
        "$CANDIDATE_BASE/Company('$BC_COMPANY')/$BC_ENTITY?tenant=$CANDIDATE_TENANT&\$top=1"
fi

echo
echo "################################################################"
echo "CONSOLIDATED RESULTS"
echo "################################################################"
printf '%-42s %-8s %-8s\n' "TEST" "HTTP" "CURL"
printf '%-42s %-8s %-8s\n' "------------------------------------------" "--------" "--------"

for RESULT in "${RESULTS[@]}"; do
    IFS='|' read -r NAME HTTP CURLRC <<< "$RESULT"
    printf '%-42s %-8s %-8s\n' "$NAME" "$HTTP" "$CURLRC"
done

echo
echo "200 = endpoint responded"
echo "401 = authentication rejected"
echo "403 = authenticated but unauthorized"
echo "404 = page/entity/path not published there"
echo "HTTP 000 + curl 28 = connection/listener/network timeout"
