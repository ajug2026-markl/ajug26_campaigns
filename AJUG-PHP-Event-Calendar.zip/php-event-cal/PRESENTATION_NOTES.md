# Presentation Notes

## Suggested session title

**From Business Central OData to a Useful Internal Application with Lightweight PHP**

## Core message

The calendar is the visible result. The reusable part is the architecture:

1. Publish/use a Business Central OData endpoint.
2. Keep transport code separate from business logic.
3. Put Business Central field names behind a mapping layer.
4. Normalize Business Central values once.
5. Keep lookups replaceable.
6. Reuse one repository for multiple consumers.

## Suggested show-and-tell order

### 1. Start with OData

Show the general shape:

```text
https://bc.example.com/<instance>/ODataV4/Company('Company Name')/<PublishedEntity>?tenant=<tenant>
```

Then show a query conceptually:

```text
$filter=Ending_Date ge <today>
$orderby=Starting_Date asc
$select=No,Description,Starting_Date,Ending_Date,...
```

Talking point:

> Let Business Central filter and sort the data it already owns instead of downloading everything and recreating the query in PHP.

### 2. Show `BusinessCentralClient.php`

This layer owns:

- connection settings
- cURL
- HTTP status handling
- JSON decoding
- OData pagination via `@odata.nextLink`

Everything else can work with PHP arrays.

### 3. Show `CampaignFields.php`

This is the architectural centerpiece.

The application asks for:

```text
event_type
hidden_on_calendar
brand_focus
```

The mapping layer knows where those values live in Business Central today.

### 4. Show normalization

Open `CampaignNormalizer.php`.

Examples:

```text
blank status     -> ACTIVE
TENATIVE         -> TENTATIVE
0001-01-01       -> null
Yes/No values    -> boolean
raw lookup code  -> friendly label
```

### 5. Show lookup extensibility

Open:

```text
src/lookups/event_types.php
src/lookups/brand_focus.php
src/lookups/stores.php
```

They are plain arrays for clarity, but the caller does not care whether the data later comes from Business Central, SQL, or another service.

### 6. Show the repository

`CampaignRepository.php` translates UI-oriented needs into OData queries:

- current/future
- date-window overlap
- find one campaign by number

### 7. Show the full calendar

Demonstrate:

- current/future events
- multi-day event behavior
- location filter
- event-type filter
- tentative formatting
- cancelled formatting
- responsive phone/tablet view
- information modal
- add-to-calendar download

### 8. Show the widget

The widget uses the same repository but different display rules:

```text
same source
same normalized model
different consumer
different business rules
```

Then show the iframe example in `examples/widget-embed.html`.

### 9. Show the troubleshooting script

`tools/test-api.sh` is useful after upgrades because it separately tests:

- service root
- metadata
- company entity
- published event entity
- required fields

That makes it easy to distinguish authentication, publication, data-context, and network/listener failures.

## Good audience discussion points

- How many integrations directly reference custom BC field names in several places?
- How many systems interpret blank/default values independently?
- Which other applications could consume the same normalized repository?
- Which lookups should eventually be owned by Business Central instead of the web application?
