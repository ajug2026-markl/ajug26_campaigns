<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/bootstrap.php';
require_once dirname(__DIR__)
    . '/src/campaigns/CampaignRepository.php';

function h(mixed $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

function widgetDateRange(?string $start, ?string $end): string
{
    if (!$start) {
        return '';
    }

    $startDate = new DateTimeImmutable($start);
    $endDate = new DateTimeImmutable($end ?: $start);

    if ($startDate->format('Y-m-d') === $endDate->format('Y-m-d')) {
        return $startDate->format('M j');
    }

    if ($startDate->format('Y-m') === $endDate->format('Y-m')) {
        return $startDate->format('M j')
            . ' - '
            . $endDate->format('j');
    }

    return $startDate->format('M j')
        . ' - '
        . $endDate->format('M j');
}

try {
    $bc = new BusinessCentralClient(bcConfigFile());
    $campaigns = new CampaignRepository($bc);

    $today = new DateTimeImmutable(
        'today',
        $bc->getTimezone()
    );

    // Final production requirement: look ahead 50 days.
    $windowEnd = $today->modify('+50 days');

    $events = $campaigns->dateWindow(
        $today,
        $windowEnd
    );

    $events = array_values(
        array_filter(
            $events,
            static function (array $event) use ($today): bool {
                $effectiveEnd =
                    $event['effective_end_date']
                    ?? $event['end_date']
                    ?? $event['start_date']
                    ?? null;

                return $effectiveEnd !== null
                    && $effectiveEnd >= $today->format('Y-m-d')
                    && !$event['hidden_on_calendar']
                    && !$event['hidden_on_comm_site'];
            }
        )
    );

    $events = array_slice($events, 0, 10);

} catch (Throwable $e) {
    http_response_code(500);
    $events = [];
    $loadError = true;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Upcoming Events</title>
    <link rel="stylesheet" href="assets/widget.css">
</head>
<body>
<?php if (isset($loadError)): ?>
    <div class="empty">Events are temporarily unavailable.</div>
<?php elseif (!$events): ?>
    <div class="empty">No upcoming events.</div>
<?php else: ?>
    <ul class="widget-list">
        <?php foreach ($events as $event): ?>
            <?php
            $classes = ['widget-event'];

            if ($event['status'] === 'TENTATIVE') {
                $classes[] = 'is-tentative';
            }

            if ($event['status'] === 'CANCELLED') {
                $classes[] = 'is-cancelled';
            }
            ?>
            <li
                class="<?= h(implode(' ', $classes)) ?>"
                title="Campaign: <?= h($event['campaign_no']) ?>">
                <span class="widget-date">
                    <?= h(widgetDateRange(
                        $event['start_date'],
                        $event['end_date']
                    )) ?>
                </span>

                <span class="widget-title">
                    <?= h($event['description']) ?>
                </span>

                <?php if (!empty($event['store_name'])): ?>
                    <span class="widget-location">
                        (<?= h($event['store_name']) ?>)
                    </span>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>
</body>
</html>
