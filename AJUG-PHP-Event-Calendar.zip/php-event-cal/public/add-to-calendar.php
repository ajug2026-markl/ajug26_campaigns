<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/bootstrap.php';
require_once dirname(__DIR__)
    . '/src/campaigns/CampaignRepository.php';

function icsEscape(string $value): string
{
    $value = str_replace('\\', '\\\\', $value);
    $value = str_replace(';', '\\;', $value);
    $value = str_replace(',', '\\,', $value);
    $value = str_replace(["\r\n", "\r", "\n"], '\\n', $value);
    return $value;
}

try {
    $campaignNo = trim((string)($_GET['campaign'] ?? ''));

    if ($campaignNo === '') {
        throw new InvalidArgumentException('Campaign number is required.');
    }

    $bc = new BusinessCentralClient(bcConfigFile());
    $campaigns = new CampaignRepository($bc);
    $event = $campaigns->find($campaignNo);

    if ($event === null || empty($event['start_date'])) {
        http_response_code(404);
        throw new RuntimeException('Event not found.');
    }

    $start = new DateTimeImmutable($event['start_date']);
    $effectiveEnd = new DateTimeImmutable(
        $event['end_date'] ?: $event['start_date']
    );

    // RFC 5545 all-day DTEND is exclusive.
    $exclusiveEnd = $effectiveEnd->modify('+1 day');

    $status = match ($event['status']) {
        'CANCELLED' => 'CANCELLED',
        'TENTATIVE' => 'TENTATIVE',
        default => 'CONFIRMED',
    };

    $descriptionParts = [
        'Campaign: ' . ($event['campaign_no'] ?? ''),
        'Event Type: ' . ($event['event_type'] ?? ''),
        'Brand / Vendor Focus: ' . ($event['brand_focus'] ?? ''),
    ];

    $uid = preg_replace(
        '/[^A-Za-z0-9_.-]+/',
        '-',
        (string)$event['campaign_no']
    ) . '@company-event-calendar.local';

    $lines = [
        'BEGIN:VCALENDAR',
        'VERSION:2.0',
        'PRODID:-//Company Name//Business Central Event Calendar//EN',
        'CALSCALE:GREGORIAN',
        'METHOD:PUBLISH',
        'BEGIN:VEVENT',
        'UID:' . $uid,
        'DTSTAMP:' . gmdate('Ymd\\THis\\Z'),
        'DTSTART;VALUE=DATE:' . $start->format('Ymd'),
        'DTEND;VALUE=DATE:' . $exclusiveEnd->format('Ymd'),
        'STATUS:' . $status,
        'SUMMARY:' . icsEscape((string)$event['description']),
        'LOCATION:' . icsEscape((string)($event['store_name'] ?? '')),
        'DESCRIPTION:' . icsEscape(implode("\n", $descriptionParts)),
        'END:VEVENT',
        'END:VCALENDAR',
    ];

    $filename = preg_replace(
        '/[^A-Za-z0-9_.-]+/',
        '-',
        (string)$event['campaign_no']
        . '-'
        . (string)$event['description']
    ) . '.ics';

    header('Content-Type: text/calendar; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    echo implode("\r\n", $lines) . "\r\n";

} catch (Throwable $e) {
    if (http_response_code() < 400) {
        http_response_code(500);
    }

    header('Content-Type: text/plain; charset=utf-8');
    echo $e->getMessage() . PHP_EOL;
}
