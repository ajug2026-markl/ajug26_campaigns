(() => {
    const locationFilter = document.getElementById('locationFilter');
    const eventTypeFilter = document.getElementById('eventTypeFilter');
    const clearFilters = document.getElementById('clearFilters');
    const rows = Array.from(document.querySelectorAll('.event-row'));
    const noResults = document.getElementById('noResults');

    function applyFilters() {
        const wantedLocation = locationFilter?.value ?? '';
        const wantedType = eventTypeFilter?.value ?? '';
        let visible = 0;

        rows.forEach((row) => {
            const location = row.dataset.location ?? '';
            const eventType = row.dataset.eventType ?? '';

            const matches =
                (!wantedLocation || location === wantedLocation)
                && (!wantedType || eventType === wantedType);

            row.hidden = !matches;

            if (matches) {
                visible++;
            }
        });

        if (noResults) {
            noResults.hidden = visible !== 0;
        }
    }

    locationFilter?.addEventListener('change', applyFilters);
    eventTypeFilter?.addEventListener('change', applyFilters);

    clearFilters?.addEventListener('click', () => {
        if (locationFilter) {
            locationFilter.value = '';
        }

        if (eventTypeFilter) {
            eventTypeFilter.value = '';
        }

        applyFilters();
    });

    const dialog = document.getElementById('eventDialog');
    const calendarLink = document.getElementById('calendarLink');

    function setText(id, value) {
        const element = document.getElementById(id);

        if (element) {
            element.textContent = value || '';
        }
    }

    document.querySelectorAll('.info-button').forEach((button) => {
        button.addEventListener('click', () => {
            if (!dialog) {
                return;
            }

            let event = {};

            try {
                event = JSON.parse(button.dataset.event || '{}');
            } catch {
                return;
            }

            setText('dialogTitle', event.description || 'Event Details');
            setText('detailCampaign', event.campaignNo);
            setText('detailDate', event.date);
            setText('detailLocation', event.location);
            setText('detailStatus', event.status);
            setText('detailType', event.eventType);
            setText('detailBrand', event.brandFocus);
            setText('detailOutbound', event.outboundingRequired);
            setText('detailOutboundDate', event.outboundingStartDate);
            setText('detailPos', event.posEnabled);

            if (calendarLink) {
                calendarLink.href =
                    'add-to-calendar.php?campaign='
                    + encodeURIComponent(event.campaignNo || '');
            }

            dialog.showModal();
        });
    });
})();
