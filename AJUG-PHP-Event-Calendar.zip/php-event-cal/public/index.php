<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/bootstrap.php';
require_once dirname(__DIR__)
    . '/src/campaigns/CampaignRepository.php';

function h(mixed $value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

function formatDateRange(?string $start, ?string $end): string
{
    if (!$start) {
        return '';
    }

    $startDate = new DateTimeImmutable($start);
    $endDate = new DateTimeImmutable($end ?: $start);

    if ($startDate->format('Y-m-d') === $endDate->format('Y-m-d')) {
        return $startDate->format('M j, Y');
    }

    if ($startDate->format('Y-m') === $endDate->format('Y-m')) {
        return $startDate->format('M j')
            . ' - '
            . $endDate->format('j, Y');
    }

    return $startDate->format('M j, Y')
        . ' - '
        . $endDate->format('M j, Y');
}

function eventHasNotEnded(
    array $event,
    DateTimeInterface $today
): bool {
    $effectiveEnd =
        $event['effective_end_date']
        ?? $event['end_date']
        ?? $event['start_date']
        ?? null;

    return $effectiveEnd !== null
        && $effectiveEnd >= $today->format('Y-m-d');
}

try {
    $bc = new BusinessCentralClient(bcConfigFile());
    $campaigns = new CampaignRepository($bc);

    $today = new DateTimeImmutable(
        'today',
        $bc->getTimezone()
    );

    $events = $campaigns->currentAndFuture();

    $events = array_values(
        array_filter(
            $events,
            static function (array $event) use ($today): bool {
                return eventHasNotEnded($event, $today)
                    && !$event['hidden_on_calendar'];
            }
        )
    );

    $locations = [];
    $eventTypes = [];

    foreach ($events as $event) {
        if (!empty($event['store_name'])) {
            $locations[(string)$event['store_name']] = true;
        }

        if (!empty($event['event_type'])) {
            $eventTypes[(string)$event['event_type']] = true;
        }
    }

    ksort($locations);
    ksort($eventTypes);

} catch (Throwable $e) {
    http_response_code(500);
    $events = [];
    $locations = [];
    $eventTypes = [];
    $loadError = $e->getMessage();
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Company Name Event Calendar</title>
    <link rel="stylesheet" href="assets/calendar.css">
</head>
<body>
<header class="site-header">
    <div class="site-header__inner">
        <div class="company-name">Company Name</div>
        <h1>Event Calendar</h1>
    </div>
</header>

<main class="page-shell">
    <?php if (isset($loadError)): ?>
        <section class="error-box">
            <h2>Event Calendar Unavailable</h2>
            <p>We were unable to retrieve events from Business Central.</p>
            <details>
                <summary>Technical detail</summary>
                <pre><?= h($loadError) ?></pre>
            </details>
        </section>
    <?php else: ?>
        <section class="filters" aria-label="Calendar filters">
            <label>
                Location
                <select id="locationFilter">
                    <option value="">All locations</option>
                    <?php foreach (array_keys($locations) as $location): ?>
                        <option value="<?= h($location) ?>">
                            <?= h($location) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>

            <label>
                Event Type
                <select id="eventTypeFilter">
                    <option value="">All event types</option>
                    <?php foreach (array_keys($eventTypes) as $type): ?>
                        <option value="<?= h($type) ?>">
                            <?= h($type) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>

            <button type="button" id="clearFilters">Clear Filters</button>
        </section>

        <div class="event-table-wrap">
            <table class="event-table">
                <thead>
                <tr>
                    <th>Date</th>
                    <th>Event</th>
                    <th>Location</th>
                    <th>Type</th>
                    <th aria-label="Information"></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($events as $event): ?>
                    <?php
                    $status = (string)$event['status'];
                    $classes = ['event-row'];

                    if ($status === 'TENTATIVE') {
                        $classes[] = 'is-tentative';
                    }

                    if ($status === 'CANCELLED') {
                        $classes[] = 'is-cancelled';
                    }

                    $details = [
                        'campaignNo' => $event['campaign_no'],
                        'description' => $event['description'],
                        'date' => formatDateRange(
                            $event['start_date'],
                            $event['end_date']
                        ),
                        'location' => $event['store_name'] ?? '',
                        'status' => $status,
                        'eventType' => $event['event_type'] ?? '',
                        'brandFocus' => $event['brand_focus'] ?? '',
                        'outboundingRequired' =>
                            $event['outbounding_required'] ? 'Yes' : 'No',
                        'outboundingStartDate' =>
                            $event['outbounding_start_date'] ?? '',
                        'posEnabled' =>
                            $event['pos_enabled'] ? 'Yes' : 'No',
                    ];
                    ?>
                    <tr
                        class="<?= h(implode(' ', $classes)) ?>"
                        data-location="<?= h($event['store_name'] ?? '') ?>"
                        data-event-type="<?= h($event['event_type'] ?? '') ?>">
                        <td data-label="Date">
                            <?= h(formatDateRange(
                                $event['start_date'],
                                $event['end_date']
                            )) ?>
                        </td>
                        <td data-label="Event">
                            <div class="event-name">
                                <?= h($event['description']) ?>
                            </div>
                            <div class="campaign-number">
                                <?= h($event['campaign_no']) ?>
                            </div>
                        </td>
                        <td data-label="Location">
                            <?= h($event['store_name'] ?? '') ?>
                        </td>
                        <td data-label="Type">
                            <?= h($event['event_type'] ?? '') ?>
                        </td>
                        <td class="info-cell">
                            <button
                                type="button"
                                class="info-button"
                                aria-label="View event details"
                                data-event='<?= h(json_encode(
                                    $details,
                                    JSON_UNESCAPED_SLASHES
                                    | JSON_UNESCAPED_UNICODE
                                )) ?>'>i</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div id="noResults" class="no-results" hidden>
            No events match the selected filters.
        </div>
    <?php endif; ?>
</main>

<dialog id="eventDialog" class="event-dialog">
    <form method="dialog">
        <button class="dialog-close" aria-label="Close" value="close">x</button>
        <h2 id="dialogTitle">Event Details</h2>

        <dl class="event-details">
            <div><dt>Campaign</dt><dd id="detailCampaign"></dd></div>
            <div><dt>Date</dt><dd id="detailDate"></dd></div>
            <div><dt>Location</dt><dd id="detailLocation"></dd></div>
            <div><dt>Status</dt><dd id="detailStatus"></dd></div>
            <div><dt>Event Type</dt><dd id="detailType"></dd></div>
            <div><dt>Brand / Vendor Focus</dt><dd id="detailBrand"></dd></div>
            <div><dt>Outbounding Required</dt><dd id="detailOutbound"></dd></div>
            <div><dt>Outbounding Start</dt><dd id="detailOutboundDate"></dd></div>
            <div><dt>Enabled on POS</dt><dd id="detailPos"></dd></div>
        </dl>

        <div class="dialog-actions">
            <a id="calendarLink" class="action-button" href="#">
                Add to Calendar
            </a>
        </div>
    </form>
</dialog>

<script src="assets/calendar.js"></script>
</body>
</html>
