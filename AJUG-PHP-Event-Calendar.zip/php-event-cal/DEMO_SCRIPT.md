# Demo Script / Talk Track

## Opening

> This is a small internal event calendar built directly from Business Central OData. The interesting part is not the HTML calendar; it is how little code is needed if the Business Central-specific pieces are isolated correctly.

> This sample deliberately avoids a large framework so the whole path from OData to screen is easy to inspect during a conference session.

## Environment

> The application runs on a normal Linux/PHP web server. Apache or Nginx is fine. PHP cURL is the main integration dependency.

Show `environment/ENVIRONMENT_SETUP.md`.

## Connection layer

> `BusinessCentralClient` has one job: talk to Business Central. It builds the request, authenticates, checks HTTP status, decodes JSON, and follows pagination.

Show `src/BusinessCentralClient.php`.

## Mapping layer

> The application should not care that Event Type happens to live in a generic extension attribute today.

Show `src/campaigns/CampaignFields.php`.

> If that value moves later, I want one mapping change, not a code chase.

## Normalization

> Business systems have representation rules. Normalize them once before they reach the UI.

Show `CampaignNormalizer.php` and point out blank status, placeholder dates, booleans, and lookups.

## Repository

> The repository gives the rest of the application useful operations: current/future, date-window overlap, and find one campaign.

Show `CampaignRepository.php`.

## Full calendar

> Current means the event has not ended yet, not merely that it starts today or later. That distinction matters for multi-day events.

Show filters, responsive layout, tentative/cancelled styling, information modal, and add-to-calendar.

## Widget

> The widget is deliberately smaller and has different rules. It looks 50 days forward, shows at most 10 events, and respects both calendar and communications visibility flags.

> We also enforce the effective end date locally. That extra check came directly from live debugging when a prior-day event remained visible.

## Troubleshooting lesson

> A successful service-root request does not prove the business-data page is returning the intended records. During an upgrade we saw service-root authentication succeed while the entity either returned no records or another candidate endpoint was unreachable.

Show `tools/test-api.sh`.

## Closing

> The takeaway is not "use PHP." The takeaway is to isolate transport, mappings, normalization, and presentation. Once that is done, a widget, full application, export, CRM integration, or scheduled process can all reuse the same data model.

> The download includes `AI_KICKSTART.md`, which attendees can upload with the source into their preferred coding assistant to adapt the sample to their own Business Central fields.
