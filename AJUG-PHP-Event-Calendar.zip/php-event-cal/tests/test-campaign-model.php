<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/bootstrap.php';
require_once dirname(__DIR__)
    . '/src/campaigns/CampaignRepository.php';

try {
    $bc = new BusinessCentralClient(bcConfigFile());
    $repo = new CampaignRepository($bc);

    $events = $repo->currentAndFuture();

    echo 'Normalized events: ' . count($events) . PHP_EOL;

    foreach (array_slice($events, 0, 5) as $event) {
        echo PHP_EOL;
        echo ($event['campaign_no'] ?? '')
            . ' | '
            . ($event['description'] ?? '')
            . PHP_EOL;
        echo '  Date: '
            . ($event['start_date'] ?? '')
            . ' -> '
            . ($event['end_date'] ?? '')
            . PHP_EOL;
        echo '  Effective End: '
            . ($event['effective_end_date'] ?? '')
            . PHP_EOL;
        echo '  Store: '
            . ($event['store_name'] ?? '')
            . PHP_EOL;
        echo '  Type: '
            . ($event['event_type'] ?? '')
            . PHP_EOL;
        echo '  Status: '
            . ($event['status'] ?? '')
            . PHP_EOL;
    }

    exit(0);

} catch (Throwable $e) {
    fwrite(
        STDERR,
        'TEST FAILED: ' . $e->getMessage() . PHP_EOL
    );

    exit(1);
}
