<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/bootstrap.php';
require_once dirname(__DIR__) . '/src/BusinessCentralClient.php';

try {
    $bc = new BusinessCentralClient(bcConfigFile());

    $rows = $bc->getCollection(
        $bc->getEntityName(),
        ['$top' => 3]
    );

    echo 'Connected successfully.' . PHP_EOL;
    echo 'Rows returned: ' . count($rows) . PHP_EOL;

    foreach ($rows as $row) {
        echo '- '
            . ($row['No'] ?? '(no number)')
            . ' | '
            . ($row['Description'] ?? '(no description)')
            . PHP_EOL;
    }

    exit(0);

} catch (Throwable $e) {
    fwrite(
        STDERR,
        'TEST FAILED: ' . $e->getMessage() . PHP_EOL
    );

    exit(1);
}
