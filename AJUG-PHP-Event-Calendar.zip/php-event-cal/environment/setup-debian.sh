#!/bin/sh
set -eu

apt update
apt install -y \
  apache2 \
  php \
  php-cli \
  php-curl \
  php-mbstring

echo
echo "PHP version:"
php -v | head -n 1

echo
echo "Relevant modules:"
php -m | grep -Ei 'curl|mbstring' || true

echo
echo "Base environment setup complete."
