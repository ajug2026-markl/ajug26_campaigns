# General Environment Setup

## Recommended baseline

A basic Linux/PHP web server is enough.

```text
Debian/Ubuntu/RHEL-family Linux
Apache 2.4 or Nginx
PHP 8.2+
PHP CLI
```

## PHP modules

Required/recommended for the base demo:

```text
curl
mbstring
```

Modern PHP includes the JSON support used by this project.

Useful checks:

```bash
php -v
php -m
php -m | grep -Ei 'curl|mbstring'
```

Optional modules if you later add spreadsheet/document features:

```text
xml
dom
simplexml
xmlreader
xmlwriter
zip
gd
fileinfo
```

## Debian/Ubuntu example

```bash
sudo apt update
sudo apt install -y \
  apache2 \
  php \
  php-cli \
  php-curl \
  php-mbstring
```

Optional extras:

```bash
sudo apt install -y \
  php-xml \
  php-zip \
  php-gd \
  composer
```

Composer is not required for the base calendar.

## Project layout

```text
config/
src/
public/
tests/
tools/
examples/
```

## Configuration

Copy:

```bash
cp config/business-central.ini.example config/business-central.ini
```

Then edit the values for your environment.

You can alternatively point to another config file with:

```bash
export BC_CONFIG_FILE=/path/to/business-central.ini
```

## CLI tests

```bash
php tests/test-business-central.php
php tests/test-campaign-model.php
```

## Built-in PHP demo server

For a conference/lab/demo environment:

```bash
php -S 0.0.0.0:8080 -t public
```

## Apache concept

```apache
<VirtualHost *:80>
    ServerName calendar.example.com
    DocumentRoot /opt/company-event-calendar/public

    <Directory /opt/company-event-calendar/public>
        Require all granted
        AllowOverride None
    </Directory>
</VirtualHost>
```

## Timezone

The sample uses a configurable timezone:

```text
timezone = "America/Chicago"
```

Date windows use that timezone.

## Browser targets

The presentation UI is designed for current:

```text
Chrome
Edge
Safari / Mobile Safari
```

The controls are touch friendly and responsive.
