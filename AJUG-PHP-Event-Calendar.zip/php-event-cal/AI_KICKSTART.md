# AI / LLM Kick-Start Instructions

This file is designed to be uploaded with the source tree into ChatGPT, Codex, Claude, Copilot, or another coding assistant.

## Project goal

Adapt a lightweight PHP event calendar to a Microsoft Dynamics 365 Business Central OData V4 campaign/event feed.

## Architecture to preserve

```text
BusinessCentralClient
    -> CampaignRepository
        -> CampaignNormalizer
            -> CampaignFields
            -> Lookups
                -> Full Calendar
                -> Embedded Widget
                -> iCalendar Download
```

Do not collapse the raw Business Central field names into the UI.

## Stable application concepts

```text
campaign_no
description
status
start_date
end_date
last_modified
store_no
store_name
pos_enabled
event_type
event_type_code
brand_focus
brand_focus_code
all_day
outbounding_required
hidden_on_calendar
hidden_on_comm_site
outbounding_start_date
```

## Example Business Central mapping

```text
campaign_no               -> No
description               -> Description
status                    -> Status_Code
start_date                -> Starting_Date
end_date                  -> Ending_Date
last_modified             -> Last_Date_Modified
store_no                  -> AJE_Store_No
pos_enabled               -> AJE_CRM_Enable_On_POS
event_type                -> AJE_Campaign_Attr_01
brand_focus               -> AJE_Campaign_Attr_05
all_day                   -> AJE_Campaign_Bool_Attr_01
outbounding_required      -> AJE_Campaign_Bool_Attr_02
hidden_on_calendar        -> AJE_Campaign_Bool_Attr_03
hidden_on_comm_site       -> AJE_Campaign_Bool_Attr_04
outbounding_start_date    -> AJE_Campaign_Date_Attr_01
```

These are examples. Ask for the actual published fields before assuming they match.

## Normalization rules

```text
blank status        -> ACTIVE
TENATIVE            -> TENTATIVE
0001-01-01          -> null
0000-00-00          -> null
boolean-like values -> bool
```

For lookups:

- preserve the raw code in `<field>_code`
- expose a friendly display value
- pass through unknown codes instead of silently dropping them

## Full calendar rules

- Show events whose effective end date is today or later.
- Effective end date = `end_date`, falling back to `start_date`.
- Exclude `hidden_on_calendar`.
- Blank status is active.
- Cancelled remains visible but struck through.
- Tentative remains visible and emphasized.
- Store display name is the location.
- Support location and Event Type filters.
- Do not rely on hover-only actions.

## Widget rules

- 50-day look-ahead.
- Maximum 10 events after filtering.
- Effective end date must be today or later.
- Exclude `hidden_on_calendar`.
- Exclude `hidden_on_comm_site`.
- Use `use ($today)` when a PHP closure needs `$today`.

## Important troubleshooting knowledge

After an upgrade, test these independently:

1. OData service root
2. `$metadata`
3. `Company`
4. event entity
5. required fields

Do not assume HTTP 200 from the service root proves the event entity is returning the correct data.

## Questions the AI assistant should ask before adapting the code

1. What is the OData V4 base URL?
2. What is the Business Central instance/service name?
3. What company name should be used?
4. Is a tenant query parameter required?
5. What is the published event/campaign entity name?
6. Which BC fields map to the stable application fields?
7. What status values exist?
8. What are the store/location codes?
9. What are the Event Type codes and labels?
10. What are the Brand/Vendor codes and labels?
11. Which visibility flags apply to the full calendar and widget?
12. Which browsers/devices need support?

## Recommended AI behavior

- Keep the implementation readable.
- Do not introduce a framework unless explicitly requested.
- Preserve transport -> mapping -> normalization -> repository -> presentation separation.
- Change Business Central mappings in the mapping layer, not in presentation code.
- Reuse the repository for new consumers.
- Keep the effective-end-date safety check on both calendar and widget.
- Validate PHP syntax after edits.
- Prefer small incremental changes that can be tested immediately.

## Starter prompt

```text
I am adapting this sanitized Business Central Event Calendar presentation project to my environment.

Read AI_KICKSTART.md, TECHNICAL_GUIDE.md, LESSONS_LEARNED.md, and the source tree first.

Preserve the architecture:
BusinessCentralClient -> CampaignRepository -> CampaignNormalizer -> CampaignFields/lookups -> presentation.

Do not rewrite it into a framework unless I ask.

First identify the minimum Business Central URL, company, tenant, entity, field mappings, and lookup values you need from me. Then help me adapt and test the project incrementally.
```
