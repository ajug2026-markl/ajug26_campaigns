# Business Central Event Calendar - Presentation Kit

This is a sanitized, conference-ready starter project showing how to turn a Microsoft Dynamics 365 Business Central OData V4 campaign/event feed into a useful internal event calendar with lightweight PHP.

The sample uses **Company Name** branding, generic stores, generic host names, and a blue/green visual theme.

## What is in the kit

- Business Central OData client
- Central field mapping layer
- Normalization layer
- Extensible lookup files
- Campaign repository/query layer
- Responsive full calendar
- Small iframe/widget view
- Per-event iCalendar (`.ics`) download
- CLI connectivity/model tests
- Consolidated API troubleshooting script
- Debian/PHP setup notes
- Presenter notes and talk track
- AI/LLM kick-start instructions
- Lessons learned from live debugging

## Architecture

```text
Business Central OData V4
          |
          v
BusinessCentralClient.php
          |
          v
CampaignRepository.php
          |
          v
CampaignNormalizer.php
       /        \
      v          v
CampaignFields  Lookups
          |
          +----------------------+
          |                      |
          v                      v
 Full Calendar             Embedded Widget
          |
          v
 Add-to-Calendar (.ics)
```

## Quick start

1. Read `environment/ENVIRONMENT_SETUP.md`.
2. Copy the sample config:

   ```bash
   cp config/business-central.ini.example config/business-central.ini
   ```

3. Edit the Business Central URL, company, tenant, entity name, username, and password.
4. Update `src/campaigns/CampaignFields.php` to match your published Business Central fields.
5. Update the files under `src/lookups/`.
6. Test the connection:

   ```bash
   php tests/test-business-central.php
   php tests/test-campaign-model.php
   ```

7. For a simple demo server:

   ```bash
   php -S 0.0.0.0:8080 -t public
   ```

8. Browse to:

   ```text
   http://server-name:8080/
   http://server-name:8080/widget.php
   ```

## Presentation business rules

### Full calendar

- Show current and future events.
- A multi-day event stays visible until its **end date** has passed.
- Exclude `Hidden on Calendar = Yes`.
- Blank status is treated as `ACTIVE`.
- `TENTATIVE` events remain visible and are emphasized.
- `CANCELLED` events remain visible and are struck through.
- Location comes from the store lookup.
- Filter by location and event type.
- Important actions work on touch devices; nothing important requires hover.

### Embedded widget

- Uses the same normalized Business Central data.
- Looks ahead **50 days**.
- Shows at most **10** visible events.
- Excludes `Hidden on Calendar = Yes`.
- Excludes `Hidden on Comm Site = Yes`.
- Explicitly removes events whose effective end date is before today.

The 50-day window is intentional in this presentation version.

## Most important design idea

Do not let presentation code depend on raw extension field names.

The UI should use stable application concepts such as:

```text
event_type
brand_focus
hidden_on_calendar
outbounding_required
```

The mapping layer can know that those currently come from fields such as:

```text
AJE_Campaign_Attr_01
AJE_Campaign_Attr_05
AJE_Campaign_Bool_Attr_03
AJE_Campaign_Bool_Attr_02
```

If the Business Central implementation changes later, update one mapping file rather than chasing field names through the application.

## Read these next

For the presenter:

- `PRESENTATION_NOTES.md`
- `DEMO_SCRIPT.md`
- `LESSONS_LEARNED.md`

For attendees/developers:

- `TECHNICAL_GUIDE.md`
- `AI_KICKSTART.md`
- `environment/ENVIRONMENT_SETUP.md`
