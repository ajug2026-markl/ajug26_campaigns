<?php

declare(strict_types=1);

final class CampaignLookup
{
    public static function resolve(
        string $lookupName,
        ?string $rawValue
    ): ?string {
        if ($rawValue === null || $rawValue === '') {
            return null;
        }

        $file = dirname(__DIR__)
            . '/lookups/'
            . $lookupName
            . '.php';

        if (!is_file($file)) {
            return $rawValue;
        }

        $lookup = require $file;

        if (!is_array($lookup)) {
            return $rawValue;
        }

        return isset($lookup[$rawValue])
            ? (string)$lookup[$rawValue]
            : $rawValue;
    }
}
