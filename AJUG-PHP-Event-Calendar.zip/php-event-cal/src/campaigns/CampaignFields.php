<?php

declare(strict_types=1);

final class CampaignFields
{
    public static function definitions(): array
    {
        return [
            'campaign_no' => [
                'bc_field' => 'No',
                'type' => 'string',
            ],
            'description' => [
                'bc_field' => 'Description',
                'type' => 'string',
            ],
            'status' => [
                'bc_field' => 'Status_Code',
                'type' => 'status',
            ],
            'start_date' => [
                'bc_field' => 'Starting_Date',
                'type' => 'date',
            ],
            'end_date' => [
                'bc_field' => 'Ending_Date',
                'type' => 'date',
            ],
            'last_modified' => [
                'bc_field' => 'Last_Date_Modified',
                'type' => 'date',
            ],
            'salesperson_code' => [
                'bc_field' => 'Salesperson_Code',
                'type' => 'string',
            ],
            'activated' => [
                'bc_field' => 'Activated',
                'type' => 'bool',
            ],
            'store_no' => [
                'bc_field' => 'AJE_Store_No',
                'type' => 'string',
            ],
            'pos_enabled' => [
                'bc_field' => 'AJE_CRM_Enable_On_POS',
                'type' => 'bool',
            ],
            'event_type' => [
                'bc_field' => 'AJE_Campaign_Attr_01',
                'type' => 'lookup',
                'lookup' => 'event_types',
            ],
            'brand_focus' => [
                'bc_field' => 'AJE_Campaign_Attr_05',
                'type' => 'lookup',
                'lookup' => 'brand_focus',
            ],
            'all_day' => [
                'bc_field' => 'AJE_Campaign_Bool_Attr_01',
                'type' => 'bool',
            ],
            'outbounding_required' => [
                'bc_field' => 'AJE_Campaign_Bool_Attr_02',
                'type' => 'bool',
            ],
            'hidden_on_calendar' => [
                'bc_field' => 'AJE_Campaign_Bool_Attr_03',
                'type' => 'bool',
            ],
            'hidden_on_comm_site' => [
                'bc_field' => 'AJE_Campaign_Bool_Attr_04',
                'type' => 'bool',
            ],
            'outbounding_start_date' => [
                'bc_field' => 'AJE_Campaign_Date_Attr_01',
                'type' => 'date',
            ],
        ];
    }

    public static function bcSelect(): string
    {
        $fields = [];

        foreach (self::definitions() as $definition) {
            $fields[] = $definition['bc_field'];
        }

        return implode(',', array_values(array_unique($fields)));
    }

    public static function bcField(string $applicationField): string
    {
        $definitions = self::definitions();

        if (!isset($definitions[$applicationField])) {
            throw new InvalidArgumentException(
                'Unknown application field: ' . $applicationField
            );
        }

        return $definitions[$applicationField]['bc_field'];
    }
}
