<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/BusinessCentralClient.php';
require_once __DIR__ . '/CampaignFields.php';
require_once __DIR__ . '/CampaignNormalizer.php';

final class CampaignRepository
{
    public function __construct(
        private BusinessCentralClient $bc
    ) {
    }

    public function currentAndFuture(): array
    {
        $today = new DateTimeImmutable(
            'today',
            $this->bc->getTimezone()
        );

        $endingDate = CampaignFields::bcField('end_date');
        $startingDate = CampaignFields::bcField('start_date');

        return $this->query([
            '$filter' =>
                $endingDate . ' ge ' . $today->format('Y-m-d'),
            '$orderby' =>
                $startingDate . ' asc',
        ]);
    }

    public function dateWindow(
        DateTimeInterface $start,
        DateTimeInterface $end
    ): array {
        $startingDate = CampaignFields::bcField('start_date');
        $endingDate = CampaignFields::bcField('end_date');

        return $this->query([
            '$filter' =>
                $startingDate . ' le ' . $end->format('Y-m-d')
                . ' and '
                . $endingDate . ' ge ' . $start->format('Y-m-d'),
            '$orderby' =>
                $startingDate . ' asc',
        ]);
    }

    public function find(string $campaignNo): ?array
    {
        $numberField = CampaignFields::bcField('campaign_no');
        $safe = str_replace("'", "''", trim($campaignNo));

        $rows = $this->query([
            '$filter' =>
                $numberField . " eq '" . $safe . "'",
            '$top' => 1,
        ]);

        return $rows[0] ?? null;
    }

    private function query(array $query): array
    {
        $query['$select'] = CampaignFields::bcSelect();

        $rawRows = $this->bc->getCollection(
            $this->bc->getEntityName(),
            $query
        );

        $rows = [];

        foreach ($rawRows as $raw) {
            $rows[] = CampaignNormalizer::normalize($raw);
        }

        return $rows;
    }
}
