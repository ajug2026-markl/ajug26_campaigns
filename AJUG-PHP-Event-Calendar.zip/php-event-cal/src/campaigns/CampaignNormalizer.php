<?php

declare(strict_types=1);

require_once __DIR__ . '/CampaignFields.php';
require_once __DIR__ . '/CampaignLookup.php';

final class CampaignNormalizer
{
    public static function normalize(array $raw): array
    {
        $result = [];

        foreach (
            CampaignFields::definitions()
            as $appField => $definition
        ) {
            $bcField = $definition['bc_field'];
            $value = $raw[$bcField] ?? null;
            $type = $definition['type'];

            if ($type === 'lookup') {
                $rawValue = self::normalizeString($value);

                $result[$appField . '_code'] = $rawValue;
                $result[$appField] = CampaignLookup::resolve(
                    (string)$definition['lookup'],
                    $rawValue
                );

                continue;
            }

            $result[$appField] = match ($type) {
                'bool' => self::normalizeBool($value),
                'date' => self::normalizeDate($value),
                'status' => self::normalizeStatus($value),
                default => self::normalizeString($value),
            };
        }

        $storeNo = (string)($result['store_no'] ?? '');

        $result['store_name'] = CampaignLookup::resolve(
            'stores',
            $storeNo
        );

        $result['effective_end_date'] =
            $result['end_date']
            ?: $result['start_date']
            ?: null;

        return $result;
    }

    private static function normalizeString(mixed $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $value = trim((string)$value);
        return $value === '' ? null : $value;
    }

    private static function normalizeBool(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_int($value)) {
            return $value !== 0;
        }

        return in_array(
            strtolower(trim((string)$value)),
            ['1', 'true', 'yes', 'y'],
            true
        );
    }

    private static function normalizeDate(mixed $value): ?string
    {
        $value = self::normalizeString($value);

        if (
            $value === null
            || $value === '0001-01-01'
            || $value === '0000-00-00'
        ) {
            return null;
        }

        return substr($value, 0, 10);
    }

    private static function normalizeStatus(mixed $value): string
    {
        $status = strtoupper(trim((string)$value));

        if ($status === '') {
            return 'ACTIVE';
        }

        if ($status === 'TENATIVE') {
            return 'TENTATIVE';
        }

        return $status;
    }
}
