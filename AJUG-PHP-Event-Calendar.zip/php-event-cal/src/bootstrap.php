<?php

declare(strict_types=1);

const PROJECT_ROOT = __DIR__ . '/..';

function bcConfigFile(): string
{
    $environment = getenv('BC_CONFIG_FILE');

    if (is_string($environment) && trim($environment) !== '') {
        return $environment;
    }

    return PROJECT_ROOT . '/config/business-central.ini';
}
