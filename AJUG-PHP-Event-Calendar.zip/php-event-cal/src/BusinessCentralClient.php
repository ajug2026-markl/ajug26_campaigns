<?php

declare(strict_types=1);

final class BusinessCentralClient
{
    private array $config;

    public function __construct(string $configFile)
    {
        $parsed = parse_ini_file(
            $configFile,
            true,
            INI_SCANNER_TYPED
        );

        if (!$parsed || !isset($parsed['business_central'])) {
            throw new RuntimeException(
                'Unable to load Business Central configuration.'
            );
        }

        $this->config = $parsed['business_central'];
    }

    public function getTimezone(): DateTimeZone
    {
        return new DateTimeZone(
            (string)($this->config['timezone'] ?? 'UTC')
        );
    }

    public function getEntityName(): string
    {
        return (string)($this->config['entity'] ?? 'CampaignDetail');
    }

    public function getCollection(
        string $entity,
        array $query = []
    ): array {
        $tenant = trim((string)($this->config['tenant'] ?? ''));

        if ($tenant !== '') {
            $query = ['tenant' => $tenant] + $query;
        }

        $url = $this->buildEntityUrl($entity);

        if ($query) {
            $url .= '?' . http_build_query(
                $query,
                '',
                '&',
                PHP_QUERY_RFC3986
            );
        }

        $rows = [];

        while ($url !== '') {
            $response = $this->requestJson($url);

            foreach ((array)($response['value'] ?? []) as $row) {
                if (is_array($row)) {
                    $rows[] = $row;
                }
            }

            $next = $response['@odata.nextLink'] ?? '';
            $url = is_string($next) ? trim($next) : '';
        }

        return $rows;
    }

    private function buildEntityUrl(string $entity): string
    {
        $base = rtrim((string)$this->config['base_url'], '/');

        $company = str_replace(
            "'",
            "''",
            (string)$this->config['company']
        );

        return $base
            . "/Company('"
            . rawurlencode($company)
            . "')/"
            . rawurlencode($entity);
    }

    private function requestJson(string $url): array
    {
        $curl = curl_init();

        if ($curl === false) {
            throw new RuntimeException('Unable to initialize cURL.');
        }

        curl_setopt_array(
            $curl,
            [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
                CURLOPT_USERPWD =>
                    (string)$this->config['username']
                    . ':'
                    . (string)$this->config['password'],
                CURLOPT_HTTPHEADER => [
                    'Accept: application/json',
                ],
                CURLOPT_CONNECTTIMEOUT =>
                    (int)($this->config['connect_timeout'] ?? 10),
                CURLOPT_TIMEOUT =>
                    (int)($this->config['request_timeout'] ?? 30),
                CURLOPT_SSL_VERIFYPEER =>
                    (bool)($this->config['verify_tls'] ?? true),
                CURLOPT_SSL_VERIFYHOST =>
                    (bool)($this->config['verify_tls'] ?? true) ? 2 : 0,
                CURLOPT_ENCODING => '',
            ]
        );

        $body = curl_exec($curl);

        if ($body === false) {
            $message = curl_error($curl);
            curl_close($curl);

            throw new RuntimeException(
                'Business Central request failed: ' . $message
            );
        }

        $status = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($status < 200 || $status >= 300) {
            throw new RuntimeException(
                'Business Central returned HTTP '
                . $status
                . ': '
                . substr((string)$body, 0, 600)
            );
        }

        $decoded = json_decode(
            (string)$body,
            true,
            512,
            JSON_THROW_ON_ERROR
        );

        return is_array($decoded) ? $decoded : [];
    }
}
