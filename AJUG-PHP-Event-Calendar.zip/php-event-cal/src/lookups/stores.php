<?php

return [
    '01' => 'Store 1',
    '02' => 'Store 2',
    '03' => 'Store 3',
    '04' => 'Store 4',
    '05' => 'Store 5',
    '90' => 'Corporate Office',
];
