<?php

return [
    'BRAND_A' => 'Brand A',
    'BRAND_B' => 'Brand B',
    'BRAND_C' => 'Brand C',
    'ESTATE' => 'Estate / Pre-Owned',
];
