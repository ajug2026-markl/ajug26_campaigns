<?php

return [
    'CMP_INVENTORY' => 'Internal - Inventory',
    'CST_EVENT' => 'Customer - In Store Event',
    'CST_PARTY' => 'Customer - In Store Party'
];
