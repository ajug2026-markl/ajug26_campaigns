# Technical Guide

## Environment

Recommended baseline:

- Linux server
- Apache or Nginx
- PHP 8.2+
- PHP CLI
- PHP cURL
- PHP mbstring

Composer is **not required** for the base presentation project.

## Business Central endpoint shape

```text
https://bc.example.com/<instance>/ODataV4/Company('Company Name')/<PublishedEntity>?tenant=<tenant>
```

The entity is configured in `config/business-central.ini`.

## Query patterns

### Current and future

```text
Ending_Date ge YYYY-MM-DD
```

### Date-window overlap

```text
Starting_Date le <window-end>
and Ending_Date ge <window-start>
```

### Sort

```text
Starting_Date asc
```

### Field selection

The repository generates `$select` from the centralized mapping in `CampaignFields.php`.

## Layer responsibilities

### `BusinessCentralClient.php`

- configuration
- Basic Auth example
- cURL
- HTTP errors
- JSON decoding
- pagination

### `CampaignFields.php`

- stable application field name
- BC source field
- data type
- lookup source
- `$select` generation

### `CampaignNormalizer.php`

- string cleanup
- boolean conversion
- placeholder-date handling
- status normalization
- lookup translation

### `CampaignRepository.php`

- current/future query
- overlap-window query
- find by Campaign No.

### `src/lookups/*.php`

- Store display names
- Event Type display names
- Brand/Vendor display names

### `public/*.php`

Consumer-specific presentation and business rules.

## Example mapping

| Application field | Example BC field |
|---|---|
| `campaign_no` | `No` |
| `description` | `Description` |
| `status` | `Status_Code` |
| `start_date` | `Starting_Date` |
| `end_date` | `Ending_Date` |
| `last_modified` | `Last_Date_Modified` |
| `store_no` | `AJE_Store_No` |
| `pos_enabled` | `AJE_CRM_Enable_On_POS` |
| `event_type` | `AJE_Campaign_Attr_01` |
| `brand_focus` | `AJE_Campaign_Attr_05` |
| `all_day` | `AJE_Campaign_Bool_Attr_01` |
| `outbounding_required` | `AJE_Campaign_Bool_Attr_02` |
| `hidden_on_calendar` | `AJE_Campaign_Bool_Attr_03` |
| `hidden_on_comm_site` | `AJE_Campaign_Bool_Attr_04` |
| `outbounding_start_date` | `AJE_Campaign_Date_Attr_01` |

These are examples from an extension-based campaign implementation. Replace them with the fields published in your environment.

## Full-calendar rules

- Query current/future events.
- Locally verify effective end date is today or later.
- Exclude hidden-on-calendar events.
- Show tentative and cancelled events with distinct styling.
- Use friendly store name as location.
- Provide location and event-type filters.
- Use touch-friendly detail controls.

## Widget rules

- Query a 50-day overlap window.
- Locally verify effective end date is today or later.
- Exclude hidden-on-calendar events.
- Exclude hidden-on-communications-site events.
- Keep the first 10 remaining events.

## iCalendar behavior

The sample creates an all-day `.ics` file from the date fields:

- `DTSTART` uses the campaign start date.
- `DTEND` is exclusive, so one day is added to the effective end date.
- Business Central status maps to `CONFIRMED`, `TENTATIVE`, or `CANCELLED`.

## Extending the sample

Natural next steps include:

- moving local lookups into Business Central
- adding caching
- exposing a JSON endpoint for another internal application
- spreadsheet exports
- scheduled change detection using `Last_Date_Modified`
- adding application-specific CRM logic while reusing the repository
