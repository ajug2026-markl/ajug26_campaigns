# Lessons Learned from the Build and Live Debugging

These are the practical changes incorporated into this presentation version.

## 1. Current/future should be based on the end date

Using only:

```text
Starting_Date >= today
```

would hide a multi-day event that started yesterday but is still active today.

The repository uses:

```text
Ending_Date >= today
```

for current/future events.

## 2. Add a presentation-layer safeguard for past events

During live use, a one-day event from the prior day remained visible.

Both the calendar and widget now explicitly calculate an **effective end date**:

```text
end_date, falling back to start_date
```

and only display it when:

```text
effective end date >= today
```

This is intentionally redundant with the OData query.

## 3. PHP closure scope matters

The widget filter needs access to `$today`.

The working form is:

```php
static function (array $event) use ($today): bool {
    // ...
}
```

Without `use ($today)`, the widget can fail even though PHP syntax validation succeeds.

## 4. The widget look-ahead is 50 days

The original design used a shorter window. The production requirement was later changed to **50 days**, while keeping a maximum of 10 visible events.

The presentation kit reflects the final 50-day behavior.

## 5. HTTP 200 does not prove the data context is correct

A service can authenticate and return valid JSON while still pointing at the wrong tenant/company/data context.

Always verify:

- base URL
- instance
- tenant
- company
- published entity
- actual returned records

## 6. Test OData in layers after an upgrade

Test these separately:

1. service root
2. `$metadata`
3. `Company`
4. published business entity
5. required `$select` fields

Useful interpretations:

```text
200          endpoint responded
401          authentication rejected
403          authenticated but unauthorized
404          page/entity/path not published there
HTTP 000 + curl 28   network/listener timeout before HTTP
```

## 7. Avoid piping long curl output directly into `head` while diagnosing

`head` can close the pipe while cURL is still writing, which may produce:

```text
curl: (23) Failure writing output to destination
```

The included API test script writes the response to a temporary file first, then previews it.

## 8. Normalize once

The application should have one interpretation for:

```text
blank status -> ACTIVE
TENATIVE -> TENTATIVE
0001-01-01 -> null
0000-00-00 -> null
```

Do not duplicate those rules in each page.

## 9. Preserve unknown lookup codes during development

If a new Event Type appears that is not in the local lookup, display the raw code instead of silently removing the value. That makes data changes visible immediately.

## 10. One data layer can support many consumers

The same Business Central campaign model can feed:

- a full calendar
- a small portal widget
- iCalendar downloads
- reports/exports
- CRM integrations
- scheduled maintenance jobs

The presentation kit focuses on the first three, but the architecture is intentionally reusable.
