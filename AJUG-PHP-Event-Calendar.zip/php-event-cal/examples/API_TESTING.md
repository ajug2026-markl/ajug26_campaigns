# API Testing Examples

Use the included consolidated script after changing Business Central versions, service tiers, or published pages.

## Test configured endpoint

```bash
tools/test-api.sh
```

## Compare a candidate endpoint

```bash
tools/test-api.sh \
  "http://new-bc.example.com:7048/newinstance/ODataV4" \
  "new-bc.example.com"
```

The script loads the existing username/password from `business-central.ini` and does not print the password.

It checks:

- service root
- metadata
- company endpoint
- event entity
- required event fields

This is useful when an upgrade leaves the service itself working but changes the tenant, instance, publication, or listener.
